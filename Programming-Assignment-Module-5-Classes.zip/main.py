import random

class Movie:
    def __init__(self,moviename0,yr0,dirt0,genre_list0,min0,rate0) -> None:
        self.moviename=moviename0
        self.yr=yr0
        self.dirt=dirt0
        self.genre_list=genre_list0
        self.min=min0
        self.rate=rate0
    def __str__(self) -> str:
        wow_biden=", ".join(self.genre_list)
        return f"\n\n{self.moviename} ({wow_biden}, {self.yr}) directed by {self.dirt}, length {self.min} minutes, rated {self.rate}"

questions = {
    "Houston, we have a problem." : 
    Movie("Apollo 13",1995,"Ron Howard",["Drama","Adventure"],140,"PG"),
    "I'll be back." : 
    Movie("Terminator",1984,"James Cameron",["Science Fiction","Horror","Action-Adventure"],107,"R"),
    "Remember who you are." : 
    Movie("The Lion King",1994,"Roger Allers",["Adventure","Musical","Animation","Kids & Family"],87,"G"),
    "I'm the king of the world!" : 
    Movie("Titanic",1997,"James Cameron",["Romance","Drama","Action","Tragedy"],195,"PG"),
    "There's no place like home." : 
    Movie("The Wizard of Oz",1939,"Victor Fleming",["Fantasy","Children's Novel"],101,"G"),
    "To infinity and beyond!" : 
    Movie("Toy Story",1995,"John Lasseter",["Animation","Adventure","Comedy","Family","Fantasy"],81,"G"),
    "Inconceivable!" : 
    Movie("The Princess Bride",1987,"Rob Reiner",["Adventure","Family","Fantasy","Romance"],98,"PG"),
    "As if!" : 
    Movie("Clueless",1995,"Amy Heckerling",["Comedy","Romance"],97,"PG"),
    "Here's Johnny!" : 
    Movie("The Shining",1980,"Stanley Kubrick",["Drama","Horror"],146,"R"),
    "It was beauty killed the beast." : 
    Movie("King Kong",2005,"Peter Jackson",["Action","Adventure","Drama","Romance"],201,"PG")
    }

while(1):
    try:
        num=int(input("How many questions would you like?"))
        break
    except:
        pass

rset = random.sample(list(questions),num)
correct_num=0
for ind,Q in enumerate(rset):
    print()
    print(f"Question #{ind+1}: From what movie is the following quote?\n\n{Q}\n")
    ans=input("Your Answer:")
    if(ans.lower()==questions[Q].moviename.lower()):
        correct_num+=1
        print("Correct!")
    else:
        print(f"Incorrect! The correct answer is: {questions[Q]}")

print(f"You answered {correct_num} out of {num} questions correctly.")